import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasky/core/constants/storage_keys.dart';
import 'package:tasky/core/errors/exceptions.dart';
import 'package:tasky/data/datasources/avatar_storage_data_source.dart';
import 'package:tasky/data/datasources/profile_local_data_source.dart';
import 'package:tasky/data/models/user_profile_model.dart';

final class ProfileLocalDataSourceImpl
    implements ProfileLocalDataSource {
  const ProfileLocalDataSourceImpl(this._preferences, this._avatarStorage);

  final SharedPreferences _preferences;
  final AvatarStorageDataSource _avatarStorage;

  @override
  Future<UserProfileModel?> getProfile() async {
    final raw = _preferences.getString(StorageKeys.userProfile);

    if (raw == null) return null;

    try {
      return UserProfileModel.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
    } on FormatException {
      return null;
    } on TypeError {
      return null;
    }
  }

  @override
  Future<void> saveProfile(UserProfileModel profile) async {
    final previousPath = (await getProfile())?.avatarPath;
    final saved = await _preferences.setString(
      StorageKeys.userProfile,
      jsonEncode(profile.toJson()),
    );

    if (!saved) {
      throw const StorageException('Could not save the profile.');
    }
    if (previousPath != null && previousPath != profile.avatarPath) {
      await _avatarStorage.deleteIfOwned(previousPath);
    }
  }

  @override
  Future<void> clearProfile() async {
    final avatarPath = (await getProfile())?.avatarPath;

    final removed = await _preferences.remove(
      StorageKeys.userProfile,
    );

    if (!removed) {
      throw const StorageException('Could not clear the profile.');
    }

    if (avatarPath != null) {
      try {
        await _avatarStorage.deleteIfOwned(avatarPath);
      } on FileSystemException {
        // Profile is already cleared; file cleanup is best-effort.
      }
    }
  }

}