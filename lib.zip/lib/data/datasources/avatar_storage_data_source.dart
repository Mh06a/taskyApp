import 'dart:io';

import 'package:path_provider/path_provider.dart';

class AvatarStorageDataSource {
  static const String _avatarDirectoryName = 'avatars';

  Future<Directory> _getAvatarDirectory() async {
    final appDirectory = await getApplicationSupportDirectory();

    final avatarDirectory = Directory(
      '${appDirectory.path}${Platform.pathSeparator}$_avatarDirectoryName',
    );

    if (!await avatarDirectory.exists()) {
      await avatarDirectory.create(recursive: true);
    }

    return avatarDirectory;
  }

  Future<String> saveAvatar(String sourcePath) async {
    final sourceFile = File(sourcePath);

    if (!await sourceFile.exists()) {
      throw const FileSystemException('Source image does not exist.');
    }

    final avatarDirectory = await _getAvatarDirectory();

    final extension = _getExtension(sourcePath);
    final fileName = 'avatar_${DateTime.now().microsecondsSinceEpoch}$extension';

    final destinationPath =
        '${avatarDirectory.path}${Platform.pathSeparator}$fileName';

    final savedFile = await sourceFile.copy(destinationPath);

    return savedFile.path;
  }

  Future<void> deleteIfOwned(String path) async {
    if (path.isEmpty) return;

    final avatarDirectory = await _getAvatarDirectory();
    final file = File(path);

    final normalizedDirectory = avatarDirectory.absolute.path;
    final normalizedFile = file.absolute.path;

    final isOwnedFile =
    normalizedFile.startsWith(
      '$normalizedDirectory${Platform.pathSeparator}',
    );

    if (!isOwnedFile) return;

    if (await file.exists()) {
      await file.delete();
    }
  }

  String _getExtension(String path) {
    final fileName = path.split(Platform.pathSeparator).last;
    final dotIndex = fileName.lastIndexOf('.');

    if (dotIndex == -1) return '.jpg';

    final extension = fileName.substring(dotIndex).toLowerCase();

    const allowedExtensions = {
      '.jpg',
      '.jpeg',
      '.png',
      '.webp',
    };

    return allowedExtensions.contains(extension) ? extension : '.jpg';
  }
}
