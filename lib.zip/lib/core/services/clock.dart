typedef Clock = DateTime Function();
