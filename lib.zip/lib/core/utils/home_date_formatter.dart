import 'package:intl/intl.dart';

abstract final class HomeDateFormatter {
  static String format(DateTime date, {String locale = 'en'}) {
    return DateFormat('EEEE, MMMM d', locale).format(date);
  }
}