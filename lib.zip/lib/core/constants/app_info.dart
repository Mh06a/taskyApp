abstract final class AppInfo {
  static const String name = 'Tasky';
  static const String version = '1.0.0';
  static const String supportEmail = 'taskSupport@gmail.com';
}
