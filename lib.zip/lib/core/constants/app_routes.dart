abstract final class AppRoutes {
  static const taskDetails = '/task-details';
}
