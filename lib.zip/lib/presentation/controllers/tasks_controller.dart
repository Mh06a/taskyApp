import 'package:flutter/foundation.dart';
import 'package:tasky/core/enums/async_status.dart';
import 'package:tasky/core/enums/priority.dart';
import 'package:tasky/core/enums/task_sort.dart';
import 'package:tasky/core/enums/task_status_filter.dart';
import 'package:tasky/core/services/clock.dart';
import 'package:tasky/domain/entities/task.dart';
import 'package:tasky/domain/entities/task_query.dart';
import 'package:tasky/domain/entities/task_stats.dart';
import 'package:tasky/domain/usecases/tasks/add_task.dart';
import 'package:tasky/domain/usecases/tasks/delete_task.dart';
import 'package:tasky/domain/usecases/tasks/filter_and_sort_tasks.dart';
import 'package:tasky/domain/usecases/tasks/get_tasks.dart';
import 'package:tasky/domain/usecases/tasks/get_task_stats.dart';
import 'package:tasky/domain/usecases/tasks/restore_task.dart';
import 'package:tasky/domain/usecases/tasks/toggle_task_done.dart';
import 'package:tasky/domain/usecases/tasks/update_task.dart';

class TasksController extends ChangeNotifier {
  TasksController({
    required GetTasks getTasks,
    required AddTask addTask,
    required UpdateTask updateTask,
    required DeleteTask deleteTask,
    required ToggleTaskDone toggleTaskDone,
    required FilterAndSortTasks filterAndSortTasks,
    required GetTaskStats getTaskStats,
    required RestoreTask restoreTask,
    Clock clock = DateTime.now,
  }) : _getTasks = getTasks,
       _addTask = addTask,
       _updateTask = updateTask,
       _deleteTask = deleteTask,
       _toggleTaskDone = toggleTaskDone,
       _filterAndSortTasks = filterAndSortTasks,
       _getTaskStats = getTaskStats,
       _restoreTask = restoreTask,
       _clock = clock;

  final GetTasks _getTasks;
  final AddTask _addTask;
  final UpdateTask _updateTask;
  final DeleteTask _deleteTask;
  final ToggleTaskDone _toggleTaskDone;
  final FilterAndSortTasks _filterAndSortTasks;
  final GetTaskStats _getTaskStats;
  final RestoreTask _restoreTask;
  final Clock _clock;

  List<Task> _tasks = <Task>[];
  TaskQuery _query = const TaskQuery();
  AsyncStatus _loadStatus = AsyncStatus.initial;
  AsyncStatus _saveStatus = AsyncStatus.initial;
  AsyncStatus _addStatus = AsyncStatus.initial;
  AsyncStatus _updateStatus = AsyncStatus.initial;
  AsyncStatus _deleteStatus = AsyncStatus.initial;
  String? _errorMessage;
  final Set<String> _togglingIds = <String>{};

  List<Task> get tasks => List.unmodifiable(_tasks);
  TaskQuery get query => _query;
  AsyncStatus get loadStatus => _loadStatus;
  AsyncStatus get saveStatus => _saveStatus;
  AsyncStatus get addStatus => _addStatus;
  AsyncStatus get updateStatus => _updateStatus;
  AsyncStatus get deleteStatus => _deleteStatus;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _loadStatus == AsyncStatus.loading;
  bool get isSaving => _addStatus == AsyncStatus.loading || _updateStatus == AsyncStatus.loading;
  bool isToggling(String id) => _togglingIds.contains(id);
  DateTime get currentTime => _clock();

  List<Task> get filteredTasks => _filterAndSortTasks(_tasks, _query);

  List<Task> get highPriorityTasks => _filterAndSortTasks(
    _tasks.where((task) => task.isHighPriority && !task.isDone).toList(),
    const TaskQuery(sort: TaskSort.newest),
  );

  /// Today section contains overdue and today's tasks, excluding items already
  /// displayed in High priority. Overdue tasks are ordered ahead of today's.
  List<Task> get todayTasks => todayTasksFor(_clock());

  List<Task> todayTasksFor(DateTime now) {
    final highIds = highPriorityTasks.map((task) => task.id).toSet();
    final visible = _tasks.where((task) =>
      !task.isDone && !highIds.contains(task.id) &&
      (task.isOverdue(now) || task.isDueToday(now))).toList();
    visible.sort((a, b) {
      final aOverdue = a.isOverdue(now);
      final bOverdue = b.isOverdue(now);
      if (aOverdue != bOverdue) return aOverdue ? -1 : 1;
      final da = a.dueDate!;
      final db = b.dueDate!;
      final dayA = DateTime(da.year, da.month, da.day);
      final dayB = DateTime(db.year, db.month, db.day);
      final dayOrder = dayA.compareTo(dayB);
      if (dayOrder != 0) return dayOrder;
      if (a.hasDueTime && b.hasDueTime) {
        final timeOrder = da.compareTo(db);
        if (timeOrder != 0) return timeOrder;
      }
      return b.createdAt.compareTo(a.createdAt);
    });
    return visible;
  }

  List<Task> get completedTasks => _filterAndSortTasks(
    _tasks.where((task) => task.isDone).toList(),
    const TaskQuery(sort: TaskSort.newest),
  );

  TaskStats get stats => _getTaskStats(_tasks, _clock());
  TaskStats get todayStats => todayStatsFor(_clock());

  TaskStats todayStatsFor(DateTime now) => _getTaskStats(
    _tasks.where((task) => task.isDueToday(now)).toList(), now,
  );

  Future<void> loadTasks() async {
    final isInitial = _loadStatus == AsyncStatus.initial;
    if (isInitial) _loadStatus = AsyncStatus.loading;
    _errorMessage = null;
    if (isInitial) notifyListeners();
    final result = await _getTasks();
    result.when(
      ok: (items) {
        _tasks = List<Task>.of(items, growable: true);
        _loadStatus = AsyncStatus.success;
      },
      err: (failure) {
        debugPrint('Tasks load failed: $failure');
        _loadStatus = AsyncStatus.failure;
        _errorMessage = 'Could not load tasks. Please try again.';
      },
    );
    notifyListeners();
  }

  Future<bool> addNewTask({
    required String title,
    String description = '',
    Priority priority = Priority.normal,
    DateTime? dueDate,
    bool hasDueTime = false,
  }) async {
    _addStatus = AsyncStatus.loading;
    _saveStatus = AsyncStatus.loading;
    _errorMessage = null;
    notifyListeners();
    final result = await _addTask(
      title: title, description: description, priority: priority,
      dueDate: dueDate, hasDueTime: hasDueTime,
    );
    var success = false;
    result.when(
      ok: (task) { _tasks.insert(0, task); _addStatus = AsyncStatus.success; _saveStatus = AsyncStatus.success; success = true; },
      err: (failure) { debugPrint('Task save failed: $failure'); _addStatus = AsyncStatus.failure; _saveStatus = AsyncStatus.failure; _errorMessage = 'Could not save task. Please try again.'; },
    );
    notifyListeners();
    return success;
  }

  Future<bool> updateExistingTask(Task task) async {
    _updateStatus = AsyncStatus.loading;
    _saveStatus = AsyncStatus.loading;
    _errorMessage = null;
    notifyListeners();
    final result = await _updateTask(task);
    var success = false;
    result.when(
      ok: (updated) {
        final index = _tasks.indexWhere((item) => item.id == updated.id);
        if (index >= 0) _tasks[index] = updated;
        _updateStatus = AsyncStatus.success;
        _saveStatus = AsyncStatus.success;
        success = true;
      },
      err: (failure) { debugPrint('Task update failed: $failure'); _updateStatus = AsyncStatus.failure; _saveStatus = AsyncStatus.failure; _errorMessage = 'Could not update task. Please try again.'; },
    );
    notifyListeners();
    return success;
  }

  Future<bool> toggleDone(Task task) async {
    if (_togglingIds.contains(task.id)) return false;
    _togglingIds.add(task.id);
    _errorMessage = null;
    notifyListeners();
    final result = await _toggleTaskDone(task);
    var success = false;
    result.when(
      ok: (updated) {
        final index = _tasks.indexWhere((item) => item.id == updated.id);
        if (index >= 0) _tasks[index] = updated;
        success = true;
      },
      err: (failure) { debugPrint('Task toggle failed: $failure'); _errorMessage = 'Could not update task status. Please try again.'; },
    );
    _togglingIds.remove(task.id);
    notifyListeners();
    return success;
  }

  Future<bool> removeTask(Task task) async {
    _deleteStatus = AsyncStatus.loading;
    _errorMessage = null;
    notifyListeners();
    final result = await _deleteTask(task.id);
    var success = false;
    result.when(
      ok: (_) { _tasks.removeWhere((item) => item.id == task.id); _deleteStatus = AsyncStatus.success; success = true; },
      err: (failure) { debugPrint('Task delete failed: $failure'); _deleteStatus = AsyncStatus.failure; _errorMessage = 'Could not delete task. Please try again.'; },
    );
    notifyListeners();
    return success;
  }

  Future<bool> restoreTask(Task task) async {
    final result = await _restoreTask(task);
    var success = false;
    result.when(
      ok: (_) { _tasks.add(task); success = true; },
      err: (failure) { debugPrint('Task restore failed: $failure'); _errorMessage = 'Could not restore task. Please try again.'; },
    );
    notifyListeners();
    return success;
  }

  void search(String value) { _query = _query.copyWith(searchText: value); notifyListeners(); }
  void changeStatus(TaskStatusFilter status) { _query = _query.copyWith(status: status); notifyListeners(); }
  void changeSort(TaskSort sort) { _query = _query.copyWith(sort: sort); notifyListeners(); }
  void toggleHighPriorityFilter(bool value) { _query = _query.copyWith(onlyHighPriority: value); notifyListeners(); }
  void resetFilters() { _query = const TaskQuery(); notifyListeners(); }
  void clearLocalTasks() { _tasks.clear(); _query = const TaskQuery(); notifyListeners(); }

  void clearError() { _errorMessage = null; if (_saveStatus == AsyncStatus.failure) _saveStatus = AsyncStatus.initial; notifyListeners(); }
}
