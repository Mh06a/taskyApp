import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


import 'package:tasky/presentation/controllers/profile_controller.dart';
import 'package:tasky/presentation/controllers/settings_controller.dart';
import 'package:tasky/presentation/controllers/tasks_controller.dart';
import 'package:tasky/domain/usecases/onboarding/get_onboarding_status.dart';

import 'package:tasky/presentation/screens/main/main_screen.dart';
import 'package:tasky/presentation/screens/onboarding/onboarding_screen.dart';
import 'package:tasky/presentation/screens/welcome/welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _startApp();
  }

  Future<void> _startApp() async {
    await Future.delayed(
      const Duration(milliseconds: 1200),
    );

    if (!mounted) return;

    final settingsController =
    context.read<SettingsController>();

    final profileController =
    context.read<ProfileController>();

    final tasksController =
    context.read<TasksController>();


    // Load app settings before deciding the next screen.
    await settingsController.loadSettings();

    if (!mounted) return;

    // Check onboarding completion.
    final onboardingCompleted =
    context.read<GetOnboardingStatus>().call();

    if (!onboardingCompleted) {
      _navigate(const OnboardingScreen());
      return;
    }

    // Load user data.
    await Future.wait([
      profileController.loadProfile(),
      tasksController.loadTasks(),
    ]);

    if (!mounted) return;

    if (profileController.profile == null) {
      _navigate(const WelcomeScreen());
    } else {
      _navigate(const MainScreen());
    }
  }

  void _navigate(Widget screen) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => screen,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                Icons.check_rounded,
                color: theme.colorScheme.onPrimary,
                size: 42,
              ),
            ),

            const SizedBox(height: 16),

            Text(
              'tasky',
              style: Theme.of(context)
                  .textTheme
                  .headlineLarge
                  ?.copyWith(
                fontSize: 32,
                fontWeight: FontWeight.w800,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              'A little focus. A lighter day.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}