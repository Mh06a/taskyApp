
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:tasky/core/constants/app_assets.dart';
import 'package:tasky/core/constants/app_info.dart';
import 'package:tasky/core/enums/app_language.dart';
import 'package:tasky/core/enums/app_theme_mode.dart';

import 'package:tasky/presentation/controllers/profile_controller.dart';
import 'package:tasky/presentation/controllers/settings_controller.dart';
import 'package:tasky/presentation/controllers/tasks_controller.dart';

import 'package:tasky/presentation/widgets/settings_tile.dart';
import 'package:tasky/presentation/widgets/choice_tile.dart';
import 'package:tasky/presentation/widgets/app_svg_icon.dart';
import 'package:tasky/presentation/widgets/profile_avatar.dart';

import 'package:tasky/presentation/screens/profile/edit_profile_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _openEditProfile(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const EditProfileScreen(),
      ),
    );
  }

  void _showThemeSheet(BuildContext context) {
    final controller = context.read<SettingsController>();

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Appearance',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Follow your device or choose a theme.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 20),

                Row(
                  children: [
                    Expanded(
                      child: _buildThemeOption(
                        context: context,
                        title: 'System',
                        image: AppAssets.systemModeImage,
                        selected:
                        controller.themeMode == AppThemeMode.system,
                        onTap: () async {
                          await controller.changeTheme(
                            AppThemeMode.system,
                          );
                          if (sheetContext.mounted) {
                            Navigator.pop(sheetContext);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildThemeOption(
                        context: context,
                        title: 'Light',
                        image: AppAssets.lightModeImage,
                        selected:
                        controller.themeMode == AppThemeMode.light,
                        onTap: () async {
                          await controller.changeTheme(
                            AppThemeMode.light,
                          );
                          if (sheetContext.mounted) {
                            Navigator.pop(sheetContext);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildThemeOption(
                        context: context,
                        title: 'Dark',
                        image: AppAssets.darkModeImage,
                        selected:
                        controller.themeMode == AppThemeMode.dark,
                        onTap: () async {
                          await controller.changeTheme(
                            AppThemeMode.dark,
                          );
                          if (sheetContext.mounted) {
                            Navigator.pop(sheetContext);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildThemeOption({
    required BuildContext context,
    required String title,
    required String image,
    required bool selected,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 6,
          vertical: 12,
        ),
        decoration: BoxDecoration(
          color: selected
              ? theme.colorScheme.primary.withValues(alpha: 0.12)
              : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected
                ? theme.colorScheme.primary
                : theme.dividerColor.withValues(alpha: 0.3),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            Image.asset(
              image,
              width: 85,
              height: 85,
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Flexible(
                  child: Text(
                    title,
                    style: theme.textTheme.bodyMedium,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (selected) ...[
                  const SizedBox(width: 4),
                  Icon(
                    Icons.check_circle_rounded,
                    size: 16,
                    color: theme.colorScheme.primary,
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showLanguageSheet(BuildContext context) {
    final controller = context.read<SettingsController>();

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Language',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Switch direction with your language.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),

                ChoiceTile(
                  title: 'System default',
                  selected: controller.language == AppLanguage.system,
                  onTap: () async {
                    await controller.changeLanguage(AppLanguage.system);
                    if (sheetContext.mounted) {
                      Navigator.pop(sheetContext);
                    }
                  },
                ),

                ChoiceTile(
                  title: 'English',
                  selected: controller.language == AppLanguage.english,
                  onTap: () async {
                    await controller.changeLanguage(AppLanguage.english);
                    if (sheetContext.mounted) {
                      Navigator.pop(sheetContext);
                    }
                  },
                ),

                ChoiceTile(
                  title: 'العربية',
                  selected: controller.language == AppLanguage.arabic,
                  onTap: () async {
                    await controller.changeLanguage(AppLanguage.arabic);
                    if (sheetContext.mounted) {
                      Navigator.pop(sheetContext);
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer2<ProfileController, SettingsController>(
      builder: (context, profileController, settingsController, child) {
        final profile = profileController.profile;

        return Scaffold(
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
              children: [
                Text(
                  'Your space',
                  style: theme.textTheme.headlineLarge,
                ),

                const SizedBox(height: 20),

                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary.withValues(
                      alpha: 0.18,
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      ProfileAvatar(
                        path: profile?.avatarPath,
                        size: 54,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              profileController.displayName,
                              style: theme.textTheme.titleMedium,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              profile?.quote ?? 'Small steps count.',
                              style: theme.textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                TextButton(
                  onPressed: () => _openEditProfile(context),
                  child: const Text('Edit profile'),
                ),

                const SizedBox(height: 20),

                Text(
                  'Preferences',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 10),

                SettingsTile(
                  leading: const AppSvgIcon(
                    assetPath: AppAssets.moonIcon,
                  ),
                  title: 'Theme',
                  subtitle: _themeLabel(settingsController.themeMode),
                  onTap: () => _showThemeSheet(context),
                ),

                const SizedBox(height: 8),

                SettingsTile(
                  leading: const AppSvgIcon(
                    assetPath: AppAssets.languageIcon,
                  ),
                  title: 'Language',
                  subtitle: _languageLabel(settingsController.language),
                  onTap: () => _showLanguageSheet(context),
                ),

                const SizedBox(height: 24),

                Text(
                  'Your data',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 10),

                SettingsTile(
                  icon: Icons.storage_outlined,
                  title: 'Offline by design',
                  subtitle: 'Your tasks live only on this device.',
                  onTap: () {
                    showAboutDialog(
                      context: context,
                      applicationName: 'Tasky',
                      applicationVersion: '1.0.0',
                      children: const [
                        Text(
                          'Your tasks and profile are stored locally on this device.',
                        ),
                      ],
                    );
                  },
                ),

                const SizedBox(height: 24),
                const SizedBox(height: 12),

                SettingsTile(
                  icon: Icons.mail_outline_rounded,
                  title: 'Contact support',
                  subtitle: AppInfo.supportEmail,
                  onTap: () => _contactSupport(context),
                ),

                const SizedBox(height: 8),

                SettingsTile(
                  icon: Icons.info_outline_rounded,
                  title: 'About Tasky',
                  subtitle: 'Version ${AppInfo.version}',
                  onTap: () => showAboutDialog(
                    context: context,
                    applicationName: AppInfo.name,
                    applicationVersion: AppInfo.version,
                    children: const [
                      Text('A little focus. A lighter day.'),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                SettingsTile(
                  leading: const AppSvgIcon(
                    assetPath: AppAssets.recycleBinIcon,
                  ),
                  title: 'Clear all data',
                  subtitle: 'Remove tasks and profile from this device',
                  onTap: () => _confirmClearData(context),
                ),

                const SizedBox(height: 20),

                Center(
                  child: Text(
                    'Tasky · A little focus. A lighter day.',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _contactSupport(BuildContext context) async {
    final uri = Uri(
      scheme: 'mailto',
      path: AppInfo.supportEmail,
      queryParameters: {'subject': 'Tasky Support'},
    );

    if (await launchUrl(uri)) return;

    await Clipboard.setData(
      const ClipboardData(text: AppInfo.supportEmail),
    );

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Support email copied to clipboard.'),
        ),
      );
    }
  }

  Future<void> _confirmClearData(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Clear all data?'),
        content: const Text(
          'This will permanently remove all tasks and your profile. App preferences will remain.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Clear all data'),
          ),
        ],
      ),
    );

    if (confirm != true || !context.mounted) return;

    final profileController = context.read<ProfileController>();
    final tasksController = context.read<TasksController>();

    final cleared = await profileController.clearUserData();

    if (!context.mounted) return;

    if (cleared) {
      tasksController.clearLocalTasks();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All personal data has been cleared.'),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            profileController.errorMessage ?? 'Could not clear data.',
          ),
        ),
      );
    }
  }

  String _themeLabel(AppThemeMode mode) {
    switch (mode) {
      case AppThemeMode.system:
        return 'System';
      case AppThemeMode.light:
        return 'Light';
      case AppThemeMode.dark:
        return 'Dark';
    }
  }

  String _languageLabel(AppLanguage language) {
    switch (language) {
      case AppLanguage.system:
        return 'System default';
      case AppLanguage.english:
        return 'English';
      case AppLanguage.arabic:
        return 'العربية';
    }
  }
}


