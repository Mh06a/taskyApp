import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:tasky/core/constants/app_sizes.dart';
import 'package:tasky/core/constants/limits.dart';
import 'package:tasky/core/validators/validators.dart';
import 'package:tasky/core/enums/validation_error.dart';
import 'package:tasky/core/enums/priority.dart';
import 'package:tasky/domain/entities/task.dart';
import 'package:tasky/presentation/controllers/tasks_controller.dart';
import 'package:tasky/presentation/widgets/app_button.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({
    super.key,
    this.task,
  });

  final Task? task;

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _titleController;
  late final TextEditingController _descriptionController;

  late Priority _priority;

  DateTime? _dueDate;
  bool _hasDueTime = false;
  bool _isSaving = false;

  bool get _isEditing => widget.task != null;

  @override
  void initState() {
    super.initState();

    final task = widget.task;

    _titleController = TextEditingController(
      text: task?.title ?? '',
    );

    _descriptionController = TextEditingController(
      text: task?.description ?? '',
    );

    _priority = task?.priority ?? Priority.normal;
    _dueDate = task?.dueDate;
    _hasDueTime = task?.hasDueTime ?? false;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = context.read<TasksController>().currentTime;

    final selected = await showDatePicker(
      context: context,
      initialDate: _dueDate ?? now,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 10),
    );

    if (selected == null || !mounted) return;

    setState(() {
      _dueDate = DateTime(
        selected.year,
        selected.month,
        selected.day,
        _hasDueTime ? (_dueDate?.hour ?? now.hour) : 0,
        _hasDueTime ? (_dueDate?.minute ?? now.minute) : 0,
      );
    });
  }

  Future<void> _pickTime() async {
    if (_dueDate == null) return;

    final selected = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_dueDate!),
    );

    if (selected == null || !mounted) return;

    setState(() {
      _dueDate = DateTime(
        _dueDate!.year,
        _dueDate!.month,
        _dueDate!.day,
        selected.hour,
        selected.minute,
      );
      _hasDueTime = true;
    });
  }

  Future<void> _saveTask() async {
    if (_isSaving || !_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final controller = context.read<TasksController>();

    final success = _isEditing
        ? await controller.updateExistingTask(
      widget.task!.copyWith(
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        priority: _priority,
        dueDate: _dueDate,
        hasDueTime: _hasDueTime && _dueDate != null,
      ),
    )
        : await controller.addNewTask(
      title: _titleController.text.trim(),
      description: _descriptionController.text.trim(),
      priority: _priority,
      dueDate: _dueDate,
      hasDueTime: _hasDueTime && _dueDate != null,
    );

    if (!mounted) return;

    setState(() => _isSaving = false);

    if (!success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            controller.errorMessage ?? 'Could not save task.',
          ),
        ),
      );
      return;
    }

    Navigator.of(context).pop();
  }

  String get _dateLabel {
    if (_dueDate == null) return 'Choose a due date';

    return MaterialLocalizations.of(context).formatMediumDate(
      _dueDate!,
    );
  }

  String get _timeLabel {
    if (_dueDate == null || !_hasDueTime) return 'Add time';

    return TimeOfDay.fromDateTime(_dueDate!).format(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit task' : 'New task'),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: EdgeInsets.all(AppSizes.s20),
            children: [
              Text(
                'What needs to be done?',
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: AppSizes.s8),

              TextFormField(
                controller: _titleController,
                autofocus: !_isEditing,
                maxLength: Limits.taskTitle,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  hintText: 'Write your task',
                  counterText: '',
                ),
                validator: (value) {
                  final error = Validators.taskTitle(value?.trim() ?? '');
                  return switch (error) {
                    null => null,
                    ValidationError.titleEmpty => 'Task title is required',
                    ValidationError.titleTooLong => 'Maximum ${Limits.taskTitle} characters',
                    _ => null,
                  };
                },
              ),

              SizedBox(height: AppSizes.s24),

              Text(
                'Description',
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: AppSizes.s8),

              TextFormField(
                controller: _descriptionController,
                maxLength: Limits.taskDescription,
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  hintText: 'Add some details (optional)',
                  alignLabelWithHint: true,
                ),
              ),

              SizedBox(height: AppSizes.s24),

              Text(
                'Priority',
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: AppSizes.s12),

              SegmentedButton<Priority>(
                expandedInsets: EdgeInsets.zero,
                segments: const [
                  ButtonSegment(
                    value: Priority.normal,
                    label: Text('Normal'),
                    icon: Icon(Icons.circle_outlined),
                  ),
                  ButtonSegment(
                    value: Priority.high,
                    label: Text('High'),
                    icon: Icon(Icons.flag_outlined),
                  ),
                ],
                selected: {_priority},
                onSelectionChanged: (selection) {
                  setState(() {
                    _priority = selection.first;
                  });
                },
              ),

              SizedBox(height: AppSizes.s24),

              Text(
                'Schedule',
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: AppSizes.s12),

              Container(
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(AppSizes.r16),
                ),
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(
                        Icons.calendar_today_outlined,
                      ),
                      title: const Text('Due date'),
                      subtitle: Text(_dateLabel),
                      trailing: const Icon(
                        Icons.chevron_right_rounded,
                      ),
                      onTap: _pickDate,
                    ),
                    Divider(
                      height: AppSizes.stroke1,
                    ),
                    SwitchListTile.adaptive(
                      secondary: const Icon(
                        Icons.access_time_rounded,
                      ),
                      title: const Text('Set a time'),
                      value: _hasDueTime,
                      onChanged: _dueDate == null
                          ? null
                          : (value) {
                        if (value) {
                          _pickTime();
                        } else {
                          setState(() {
                            _hasDueTime = false;
                          });
                        }
                      },
                    ),
                    if (_hasDueTime && _dueDate != null)
                      ListTile(
                        leading: const Icon(
                          Icons.schedule_rounded,
                        ),
                        title: const Text('Time'),
                        subtitle: Text(_timeLabel),
                        trailing: const Icon(
                          Icons.chevron_right_rounded,
                        ),
                        onTap: _pickTime,
                      ),
                    if (_dueDate != null)
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _dueDate = null;
                            _hasDueTime = false;
                          });
                        },
                        child: const Text('Remove date'),
                      ),
                  ],
                ),
              ),

              SizedBox(height: AppSizes.s32),

              AppButton(
                text: _isEditing ? 'Save changes' : 'Create task',
                isLoading: _isSaving,
                onPressed: _saveTask,
              ),
            ],
          ),
        ),
      ),
    );
  }
}